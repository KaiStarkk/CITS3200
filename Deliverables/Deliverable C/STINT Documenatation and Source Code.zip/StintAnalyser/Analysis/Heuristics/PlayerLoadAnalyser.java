package StintAnalyser.Analysis.Heuristics;

import StintAnalyser.Data.Column;
import StintAnalyser.Data.DataSet;
import StintAnalyser.Stints.Stint;
import StintAnalyser.Stints.StintSet;

/**
 * CITS3200 Professional Computing AccelerometerHeuristic.java Determines if a
 * player is playing on not depending on their accelerometer data.
 *
 * @version 1.1 20/08/14
 * @author Cameron and Alex
 */
public class PlayerLoadAnalyser {
    DataSet dataSet;
    
        /**
         * Constructor for PlayerLoadAnalyser
         * @param dataSet the input data
         */
        public PlayerLoadAnalyser(DataSet dataSet) {
            this.dataSet = dataSet;
        }

        /**
	 * Determine the average player load between two times
	 *
         * @param start the start time for player load to be averaged
         * @param end the end time to be averaged
	 * @return the average player load value of the 2 times
	 */
        public double average(int start, int end){
            Column time = dataSet.getTimeColumn();
            Column pLoad = dataSet.getPlayerLoadColumn();
            
            int indexStart = time.getIndexInRange(start);
            int indexEnd = time.getIndexInRange(end);
            
            int index = indexStart;
            double totalpLoad = 0;
            int duration = indexEnd - indexStart;
            
            for(int i = 0; i < duration; i++){
                totalpLoad = totalpLoad + (double)pLoad.get(index);
                index++;
            }
            
            return (totalpLoad/duration);
        }
        
	/**
	 * Determine if the player is playing or not.
	 *
	 * @return
	 */
        /*
	public StintSet findStints() {

		//experimental number will be changed to a calculated number
		double sig_activity = 10;
		boolean found_start = false;

		Column time = dataSet.getGPStimeColumn();
		Column accel = dataSet.getPlayerLoadColumn();
		StintSet solution = new StintSet();

		//check correct data
		if (time.length() != accel.length()) {
			return null;

		}
		double estimated_start = 0;

		int ticks = 0;
		int tick_threshold_start = 100;
		int tick_threshold_end = 100;
		int stint_number = 1;

		for (int i = 0; i < time.length(); i++) {

			double c_time = (double) time.get(i);
			double c_accel = (double) accel.get(i);

			if (found_start) {
				if (c_accel < sig_activity) {

					ticks++;
					if (ticks > tick_threshold_end) {

						double end_time = (double) time.get(i - 100);
						//solution.addStint(new Stint(estimated_start, end_time, 0, 0, 0));
					}
				} else {

					ticks = 0;
				}

			} else {

				//continue
			}

		}

		return new StintSet();
	}
        */

}
